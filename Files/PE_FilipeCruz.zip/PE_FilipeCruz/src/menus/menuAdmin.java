package menus;

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

import static bibliotecas.bibliotecaAdmin.*;
import static globais.funcoesGlobais.*;

public class menuAdmin {

    /**
     *Menu do administrador, cria uma matriz bilhetes para uso nas várias opções do menu. Cada opção selecionada chama a função correspondente (com ou sem verificação). Escrever uma resposta que não está nas opções retorna uma mensagem de erro e volta a mostrar o menu. Ao escrever "0" a função termina e retorna ao menu anterior. Caso não encontre o ficheiro Festival_Bilhetes.csv apresenta uma mensagem de erro e regressa ao menu anterior.
     */
    public static void menuA(){
        Scanner input = new Scanner(System.in);
        String opcao, resposta;

        try {
            String[][] bilhetes = transformarFileMatriz(new File("files/Festival_Bilhetes.csv"),";",false);

            do {
                System.out.println("_________ADMINISTRADOR_________");
                System.out.println("\nOpções:");
                System.out.println("1.Consulta de Ficheiros csv");
                System.out.println("2.Total de Bilhetes Vendidos");
                System.out.println("3.Pesquisa de Festivaleiro");
                System.out.println("4.Bilhete Mais Caro");
                System.out.println("5.Melhor Festivaleiro");
                System.out.println("6.Pesquisa de Bilhetes por Dia");
                System.out.println("7.Receita por Tipo de Bilhete");
                System.out.println("8.Receita por Dia do Festival");
                System.out.println("0.Sair");
                System.out.print("\nOpção: ");
                opcao = input.next();

                switch (opcao) {
                    case "1":
                        consultaFicheiros();
                        break;
                    case "2":
                        totalBilhetes(bilhetes);
                        break;
                    case "3":
                        pesquisaFes(bilhetes);
                        break;
                    case "4":
                        bilheteCaro(bilhetes);
                        break;
                    case "5":
                        melhorFes(bilhetes);
                        break;
                    case "6":
                        do {
                            terminar();
                            System.out.println("_________PESQUISAR POR DIA_________");
                            System.out.print("\nDia a pesquisar: ");
                            resposta = input.next();
                            if (verificarDia(resposta)) {
                                pesquisaAdmin(bilhetes, resposta);
                            }
                        }while(simNao());
                        terminar();
                        break;
                    case "7":
                        do {
                            terminar();
                            System.out.println("_________PESQUISAR BILHETES_________");
                            System.out.print("\nTipo de bilhete a pesquisar: ");
                            resposta = input.next();
                            if (verificar(bilhetes, resposta,6)) {
                                receitaBilhete(bilhetes, resposta);
                            }
                        }while(simNao());
                        terminar();
                        break;
                    case "8":
                        receitaDia(bilhetes);
                        break;
                    case "0":
                        terminar();
                        break;
                    default:
                        System.out.println("\n!ERRO!\nEscolha uma opção válida.\n");
                        limparConsola();
                }
            } while (!opcao.equals("0"));
        } catch (FileNotFoundException exc){
            System.out.println("!ERRO!\nFicheiro não encontrado!\nVerifique o estado do ficheiro Festival_Bilhetes.csv e volte a tentar.");
            limparConsola();
        }
    }
}
