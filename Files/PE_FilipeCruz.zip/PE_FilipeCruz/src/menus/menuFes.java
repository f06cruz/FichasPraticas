package menus;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import static bibliotecas.bibliotecaFes.*;
import static globais.funcoesGlobais.*;

public class menuFes {

    /**
     *Menu do festivaleiro, cria uma matriz cartaz e uma matriz quiz para uso nas várias opções do menu. Cada opção selecionada chama a função correspondente (com ou sem verificação). Escrever uma resposta que não está nas opções retorna uma mensagem de erro e volta a mostrar o menu. Ao escrever "0" a função termina e retorna ao menu anterior.
     * @throws FileNotFoundException
     */
    public static void menuF() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        String opcao, resposta;

        String[][] cartaz = transformarFileMatriz(new File("files/Festival_Cartaz.csv"),";",false);
        String[][] quiz = transformarFileMatriz(new File("files/Festival_Quiz.csv"),";",false);

        do{
            System.out.println("***** FESTIVALEIRO *****");
            System.out.println("\nOpções:");
            System.out.println("1.Novo Registo");
            System.out.println("2.Procurar Lugar de Campismo");
            System.out.println("3.Imprimir cartaz");
            System.out.println("4.Imprimir Gráfico do Palco");
            System.out.println("5.Imprimir Concerto Mais Longo");
            System.out.println("6.Imprimir cartaz por Dia");
            System.out.println("7.Imprimir cartaz por Género Musical");
            System.out.println("8.Quiz Musical");
            System.out.println("0.Sair");
            System.out.print("\nOpção: ");
            opcao = input.next();

            switch (opcao) {
                case "1":
                    novoRegisto();
                    break;
                case "2":
                    campismo();
                    break;
                case "3":
                    impCartaz(cartaz);
                    break;
                case "4":
                    palcos();
                    break;
                case "5":
                    concertoLongo(cartaz);
                    break;
                case "6":
                    do {
                        terminar();
                        System.out.println("***** PESQUISAR POR DIA *****");
                        System.out.print("\nDia a pesquisar: ");
                        resposta = input.next();
                        if (verificarDia(resposta)) {
                            pesquisaFes(cartaz, resposta,1);
                        }
                    }while(simNao());
                    terminar();
                    break;
                case "7":
                    do {
                        terminar();
                        System.out.println("***** PESQUISAR POR GÉNERO *****");
                        System.out.print("\nGénero de música a pesquisar: ");
                        resposta = input.next();
                        if (verificar(cartaz, resposta,5)) {
                            pesquisaFes(cartaz, resposta,5);
                        }
                    }while(simNao());
                    terminar();
                    break;
                case "8":
                    quizFes(quiz);
                    break;
                case "0":
                    terminar();
                    break;
                default:
                    System.out.println("\n!ERRO!\nEscolha uma opção válida.\n");
                    limparConsola();
            }
        } while (!opcao.equals("0"));
    }
}