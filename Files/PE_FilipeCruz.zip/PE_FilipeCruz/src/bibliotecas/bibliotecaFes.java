package bibliotecas;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

import static globais.funcoesGlobais.*;

public class bibliotecaFes {

    /**
     * A função simula a criação de um novo festivaleiro, mostrando uma mensagem de sucesso e os dados introduzidos. A função pode ser reutilizada imediatamente através da função simNao.
     */
    public static void novoRegisto(){
        Scanner input = new Scanner(System.in);

        do {
            terminar();
            String[] novo = new String[3];
            System.out.println("***** Registar Festivaleiro *****");
            System.out.print("\nInsira Nome: ");
            novo[0] = input.next();
            System.out.print("\nInsira Contacto: ");
            novo[1] = input.next();
            System.out.print("\nInsira Email: ");
            novo[2] = input.next();
            System.out.println("\nFESTIVALEIRO REGISTADO\nDados:\n" + novo[0] + " | " + novo[1] + " | " + novo[2]);
        } while(simNao());
        terminar();
    }

    /**
     * A função imprime os lugares disponíveis sendo estes números triangulares múltiplos de 5 entre 1 e 300.
     */
    public static void campismo(){
        int num;

        terminar();
        System.out.println("***** Lugares Disponíveis *****\n");
        for(int x=1;x<301;x++){
            num=x*(x+1)/2;
            if (num%5==0&&num<301)
                System.out.println(num);
        }
        limparConsola();
    }

    /**
     * Imprime todos os artistas no cartaz do festival, sem duplicados e ordenados por ordem crescente (funcionalidade extra).
     * @param cartaz Matriz cartaz obtida do Menu Festivaleiro.
     */
    public static void impCartaz(String [][] cartaz){
        String [] artistas = new String[cartaz.length];
        int cont=0;
        boolean teste;

        terminar();
        artistas[0]=cartaz[0][4];
        for (int x=0; x<cartaz.length;x++){
            teste =false;
            for (int y = 0; y <=cont; y++) {
                if (cartaz[x][4].equals(artistas[y])) {
                    teste = false;
                    break;
                } else {
                    teste = true;
                }
            }
            if(teste){
                cont++;
                artistas[cont]=cartaz[x][4];
            }
        }
        Arrays.sort(artistas); //Ordena um array por ordem crescente (strings e inteiros). w3schools
        System.out.println("***** ARTISTAS EM CARTAZ *****\n");
        for (int z = 0; z <=cont; z++) {
            System.out.println(artistas[z]);
        }
        limparConsola();
    }

    /**
     *Apresenta um menu com várias opções. Cada opção imprime um ficheiro txt diferente no ecrã. A função pode ser reutilizada imediatamente através da função simNao.
     * @throws FileNotFoundException
     */
    public static void palcos() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        String opcao;

        do {
            terminar();
            System.out.println("***** PALCOS *****");
            System.out.println("\nOpções:");
            System.out.println("1.Palco Main");
            System.out.println("2.Palco Java");
            System.out.println("3.Palco Commit");
            System.out.print("\nOpção: ");
            opcao = input.next();
            terminar();
            switch (opcao) {
                case "1":
                    lerImprimirFile("files/Palco_Main.txt");
                    break;
                case "2":
                    lerImprimirFile("files/Palco_Java.txt");
                    break;
                case "3":
                    lerImprimirFile("files/Palco_Commit.txt");
                    break;
                default:
                    System.out.println("\nErro\nEscolha uma opção válida.\n");
            }
        }while (simNao());
        terminar();
    }

    /**
     * A função calcula e apresenta o concerto com a maior duração.
     * @param cartaz Matriz cartaz obtida do Menu Festivaleiro.
     */
    public static void concertoLongo(String [][] cartaz){
        int maior=0;

        terminar();
        for (int linha=0; linha<cartaz.length;linha++){
            if (maior<Integer.parseInt(cartaz[linha][6])){
                maior=Integer.parseInt(cartaz[linha][6]);
            }
        }
        System.out.println("***** CONCERTO MAIS LONGO *****");
        for (int linha=0; linha<cartaz.length;linha++){
            if (maior==Integer.parseInt(cartaz[linha][6])){
                System.out.println("\nArtista: "+cartaz[linha][4]);
                System.out.println("Dia: "+cartaz[linha][1]);
                System.out.println("Hora: "+cartaz[linha][2]);
                System.out.println("Palco: "+cartaz[linha][3]);
                System.out.println("Género: "+cartaz[linha][5]);
                System.out.println("Duração: "+cartaz[linha][6]+" mins.");
            }
        }
        limparConsola();
    }

    /**
     * A função recebe a matriz, uma string e um valor. E procura a string na coluna, indicada pelo valor, dentro da matriz. Os dados que a função imprime dependem do valor. A função pode ser reutilizada imediatamente através da função simNao (chamada no menu anterior).
     * @param matriz Matriz cartaz obtida do Menu Festivaleiro.
     * @param resposta String (já verificada) para ser procurada.
     * @param valor Valor inteiro dado pelo menu anterior
     */
    public static void pesquisaFes(String [][] matriz, String resposta, int valor){
        if (valor==1)
            System.out.println("\n***** CARTAZ DE "+ resposta.toUpperCase()+" *****\n");
        if (valor==5)
            System.out.println("\n***** CONCERTOS DE "+ resposta.toUpperCase()+" *****\n");
        for (int linha = 0; linha < matriz.length; linha++) {
            if (matriz[linha][valor].equalsIgnoreCase(resposta)) {
                if (valor==1)
                    System.out.println(matriz[linha][2] + " | " + matriz[linha][3] + " | " + matriz[linha][4] + " | " + matriz[linha][5] + " | " + matriz[linha][6]+" mins.");
                if (valor==5)
                    System.out.println(matriz[linha][4] + " | " + matriz[linha][1] + " | " + matriz[linha][2] + " | " + matriz[linha][3] + " | " + matriz[linha][6]+" mins.");
            }
        }
    }

    /**
     * A função imprime várias perguntas e opções de resposta para cada uma. O utilizador seleciona a resposta que acha correcta e recebe uma mensagem se acertou ou errou. No final imprime o resultado do utilizador e apresenta uma mensgem de felicitação caso tenha a pontuação máxima (funcionalidade extra). A função pode ser reutilizada imediatamente através da função simNao.
     * @param quiz Matriz quiz obtida do Menu Festivaleiro.
     */
    public static void quizFes(String [][] quiz){
        Scanner input = new Scanner(System.in);

        do{
            terminar();
            System.out.println("***** QUIZ MUSICAL *****");
            int pontos=0;
            String resposta;
            for (int pergunta=0; pergunta<quiz.length;pergunta++) {
                System.out.println("\nPergunta " + (pergunta + 1) + " :");
                System.out.println(quiz[pergunta][0]);
                System.out.println("1. " + quiz[pergunta][1]);
                System.out.println("2. " + quiz[pergunta][2]);
                System.out.println("3. " + quiz[pergunta][3]);
                System.out.println("4. " + quiz[pergunta][4]);
                System.out.print("\nResposta: ");
                resposta = input.next();
                while (!resposta.equals("1") && !resposta.equals("2") && !resposta.equals("3") && !resposta.equals("4")) {
                    System.out.println("\n!ERRO!\nResposta não válida\n");
                    System.out.print("\nResposta: ");
                    resposta = input.next();
                }
                if (resposta.equals(quiz[pergunta][5])) {
                    System.out.println("\nResposta correta!");
                    pontos++;
                } else System.out.println("\nResposta errada!");
            }
            System.out.println("\nQuiz Terminado!");
            if (pontos==quiz.length){
                System.out.println("\nPARABÉNS\nPontuação Máxima!\nRespostas Corretas: "+pontos+"/"+quiz.length);
            }if (pontos==0) {
                System.out.println("\nPARABÉNS\nFalhaste todas as respostas!\nRespostas Corretas: " + pontos + "/" + quiz.length);
            }else System.out.println("\nRespostas Corretas: "+pontos+"/"+quiz.length);
        } while(simNao());
        terminar();
    }

}
