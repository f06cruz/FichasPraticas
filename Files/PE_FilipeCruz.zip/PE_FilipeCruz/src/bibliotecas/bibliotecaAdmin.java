package bibliotecas;

import java.io.FileNotFoundException;
import java.util.Scanner;

import static globais.funcoesGlobais.*;

public class bibliotecaAdmin {

    /**
     *Apresenta um menu com várias opções. Cada opção imprime um ficheiro csv diferente no ecrã. A função pode ser reutilizada imediatamente através da função simNao.
     * @throws FileNotFoundException
     */
    public static void consultaFicheiros() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        String opcao;

        do {
            terminar();
            System.out.println("_________CONSULTAR FICHEIROS_________\n");
            System.out.println("Opções:");
            System.out.println("1.Festival_Bilhetes.csv");
            System.out.println("2.Festival_Cartaz.csv");
            System.out.println("3.Festival_AdminLogin.csv");
            System.out.println("4.Festival_Quiz.csv");
            System.out.print("\nOpção: ");
            opcao = input.next();
            terminar();
            switch (opcao) {
                case "1":
                    lerImprimirFile("files/Festival_Bilhetes.csv");
                    break;
                case "2":
                    lerImprimirFile("files/Festival_Cartaz.csv");
                    break;
                case "3":
                    lerImprimirFile("files/Festival_AdminLogin.csv");
                    break;
                case "4":
                    lerImprimirFile("files/Festival_Quiz.csv");
                    break;
                default:
                    System.out.println("\n!ERRO!\nEscolha uma opção válida.\n");
            }
        }while (simNao());
        terminar();
    }

    /**
     *Recebe a matriz bilhetes e calcula o total de bilhetes vendidos. Depois imprime o número de bilhtes vendidos e o seu total com duas casas decimais.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     */
    public static void totalBilhetes(String [][] bilhetes){
        double total=0;

        terminar();
        System.out.println("_________TOTAL DE BILHETES VENDIDOS_________");
        for (int x = 0; x < bilhetes.length; x++) {
            total+=Double.parseDouble(bilhetes[x][7]);
        }
        total= (double) Math.round(total * 100) /100; // Arredonda para o inteiro mais próximo, *100 "puxa" duas casas decimais para a esquerda e o/100 volta a empurar para a direita depois de arredondar. w3schools
        System.out.println("\nForam vendidos "+bilhetes.length+" bilhetes.\nO valor total de vendas foi de "+total+"€.");
        limparConsola();
    }

    /**
     *Recebe a matriz bilhetes e pergunta o ID do festivaleiro a pesquisar. Depois chama a função festivaleiro para verificar a existencia do festivaleiro, caso exista imprime os seus dados e chama a função imprimirBilhetes para imprimir os bilhetes comprados e o valor total dos mesmos. Se o festivaleiro não existir apenas imprime uma mensagem de erro. A função pode ser reutilizada imediatamente através da função simNao (chamada no menu anterior).
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     */
    public static void pesquisaFes(String [][] bilhetes){
        Scanner input = new Scanner(System.in);
        String idFes;

        do {
            terminar();
            System.out.println("_________PESQUISA DE FESTIVALEIRO_________\n");
            System.out.print("Insira o ID do festivaleiro: ");
            idFes= input.next();
            if (festivaleiro(bilhetes,idFes)){
                imprimirBilhetes(bilhetes,idFes);
            }
        }while (simNao());
        terminar();
    }

    /**
     *Verifica a existencia do festivaleiro na matris bilhetes através do idFes introduzido pelo utilizador. Caso exista imprime os dados do mesmo. Caso não exista imprime uma mensagem de erro.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     * @param idFes ID do festivaleiro introduzido pelo utilizador na função anterior.
     * @return Retorna true caso o festivaleiro exista ou false em caso contrário.
     */
    public static boolean festivaleiro(String [][] bilhetes, String idFes){
        for (int linha = 0; linha < bilhetes.length; linha++) {
            if (bilhetes[linha][1].equals(idFes)) {
                System.out.println("\n_________FESTIVALEIRO ENCONTRADO_________\n");
                System.out.println("Nome: "+bilhetes[linha][2]);
                System.out.println("Contacto: "+bilhetes[linha][3]);
                System.out.println("Email: "+bilhetes[linha][4]);
                return true;
            }
        }
        System.out.println("\n_________FESTIVALEIRO NÃO ENCONTRADO_________");
        return false;
    }

    /**
     * Imprime todos os bilhetes comprados por um festivaleiro, fornecido pelo utilizador, e o respectivo total.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     * @param idFes ID do festivaleiro introduzido pelo utilizador na função anterior.
     */
    public static void imprimirBilhetes(String [][] bilhetes, String idFes){
        String nome="";
        double total=0;

        for (int linha = 0; linha < bilhetes.length; linha++) {
            if (bilhetes[linha][1].equals(idFes)) {
                nome = bilhetes[linha][2];
                break;
            }
        }
        System.out.println("\nBilhetes:");
        for (int linha = 0; linha < bilhetes.length; linha++) {
            if (bilhetes[linha][2].equals(nome)) {
                System.out.println("-"+bilhetes[linha][0]+" | "+bilhetes[linha][5]+" | "+bilhetes[linha][6]+" | "+bilhetes[linha][7]);
                total+=Double.parseDouble(bilhetes[linha][7]);
            }
        }
        total= (double) Math.round(total * 100) /100;
        System.out.println("\nTotal gasto: "+total+"€");
    }

    /**
     *A função procura o bilhete mais caro da matriz bilhetes e imprime os respectivos dados.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     */
    public static void bilheteCaro(String [][] bilhetes){
        double valor=Double.parseDouble(bilhetes[0][7]);
        String[] maior = new String[3];

        terminar();
        for (int coluna = 0; coluna < 3; coluna++) {
            maior[coluna]=bilhetes[0][coluna+5];
        }
        for (int linha = 0; linha < bilhetes.length; linha++) {
            if (Double.parseDouble(bilhetes[linha][7]) > valor) {
                for (int coluna = 0; coluna < 3; coluna++) {
                    maior[coluna]=bilhetes[0][coluna+5];
                }
            }
        }
        System.out.println("_________BILHETE MAIS CARO_________\n");
        System.out.println("Dia: "+maior[0]);
        System.out.println("Tipo de bilhete: "+maior[1]);
        System.out.println("Valor: "+maior[2]);
        limparConsola();
    }

    /**
     *A função procura o festivaleiro que tenha gasto o maior valor usa as funções festivaleiro e imprimirBilhetes para imprimir os respectivos dados.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     */
    public static void melhorFes(String [][] bilhetes) {
        double maior=0,total;
        String idFes="";

        for (int x = 0; x < bilhetes.length; x++) {
            total = 0;
            for (int y = 0; y < bilhetes.length; y++) {
                if (bilhetes[y][2].equals(bilhetes[x][2])) {
                    total += Double.parseDouble(bilhetes[y][7]);
                }
            }
            if (total > maior) {
                maior = total;
                idFes=bilhetes[x][1];
            }
        }
        System.out.println("_________MELHOR FESTIVALEIRO_________\n");
        festivaleiro(bilhetes, idFes);
        imprimirBilhetes(bilhetes, idFes);
        limparConsola();
    }

    /**
     * A função recebe um dia da semana e imprime vários dados sobre o mesmo. A função pode ser reutilizada imediatamente através da função simNao (chamada no menu anterior).
     * @param matriz Matriz bilhetes obtida do Menu Administrador.
     * @param dia Dia da semana (já verificado) para ser procurado.
     */
    public static void pesquisaAdmin(String [][] matriz, String dia){
        System.out.println("\n_________BILHETES PARA " + dia.toUpperCase() + "_________\n");
        for (int linha = 0; linha < matriz.length; linha++) {
            if (matriz[linha][5].equalsIgnoreCase(dia)) {
                System.out.println("-"+matriz[linha][0] + " | " + matriz[linha][2] + " | " + matriz[linha][3] + " | " + matriz[linha][6] + " | " + matriz[linha][7]);
            }
        }
    }

    /**
     *A função recebe um tipo de bilhete e imprime vários dados sobre o mesmo. A função pode ser reutilizada imediatamente através da função simNao (chamada no menu anterior).
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     * @param tipo Tipo de bilhete (já verificado) para ser procurado.
     */
    public static void receitaBilhete(String [][] bilhetes,String tipo){
        int cont=0;
        double total=0;

        terminar();
        for (int linha = 0; linha < bilhetes.length; linha++) {
            if (bilhetes[linha][6].equalsIgnoreCase(tipo)) {
                total+=Double.parseDouble(bilhetes[linha][7]);
                cont++;
            }
        }
        total= (double) Math.round(total * 100) /100;
        System.out.println("\n_________BILHETES "+tipo.toUpperCase()+"_________\n");
        System.out.println("Foram vendidos "+cont+" bilhetes "+tipo+".\nO valor total de vendas foi de "+total+"€.");
    }

    /**
     * A função calcula e imprime o número e valor total de bilhetes vendidos por dia.
     * @param bilhetes Matriz bilhetes obtida do Menu Administrador.
     */
    public static void receitaDia(String [][] bilhetes){
        String[] dias = new String[]{"Sexta", "Sábado", "Domingo"};
        int[] nBilhetes = new int[]{0,0,0};
        double[] valorTotal = new double[]{0,0,0};

        terminar();
        for (int x = 0; x < 3; x++) {
            for (int y = 0; y < bilhetes.length; y++) {
                if (bilhetes[y][5].equalsIgnoreCase(dias[x])) {
                    nBilhetes[x]++;
                    valorTotal[x]+=Double.parseDouble(bilhetes[y][7]);
                }
            }
        }
        System.out.println("\n_________RECEITA POR DIA_________");
        for (int x = 0; x < 3; x++) {
            System.out.println("\n"+dias[x]+": ");
            System.out.println("Foram vendidos "+nBilhetes[x]+" bilhetes.\nO valor total de vendas foi de "+((double) Math.round(valorTotal[x] * 100) /100)+"€.");
        }
        limparConsola();
    }

}
