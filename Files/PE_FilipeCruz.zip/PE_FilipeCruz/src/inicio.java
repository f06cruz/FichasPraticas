import java.io.FileNotFoundException;
import java.util.Scanner;

import static globais.funcoesGlobais.*;
import static menus.menuAdmin.menuA;
import static menus.menuFes.menuF;


public class inicio {

    /**
     *Função main e menu inicial do programa. Cada opção selecionada chama a função correspondente. Escrever uma resposta que não está nas opções retorna uma mensagem de erro e volta a mostrar o menu. Ao escrever "0" o programa mostra o ficheiro "Festival_Copyright.txt", caso este não exista usa a função fecho() de funcoesGlobais como substituto, e termina.
     * @param args
     */
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String opcao;

        terminar();
        do {
            System.out.println("***** CodeFest *****");
            System.out.println("\nTipo de Utilizador:");
            System.out.println("1.Administrador");
            System.out.println("2.Festivaleiro");
            System.out.println("0.Sair");
            System.out.print("\nOpção: ");
            opcao = input.next();

            switch (opcao) {
                case "1":
                    if (autentificacao()) {
                        menuA();
                    }
                    break;
                case "2":
                    terminar();
                    menuF();
                    break;
                case "0":
                    terminar();
                    break;
                default:
                    System.out.println("\n!ERRO!\nEscolha uma opção válida.\n");
                    limparConsola();
            }
        } while (!opcao.equals("0"));
        try {
            lerImprimirFile("files/Festival_Copyright.txt");
        } catch (FileNotFoundException exc){
            fecho();
        }
        System.out.println("\nA terminar...");
    }
}